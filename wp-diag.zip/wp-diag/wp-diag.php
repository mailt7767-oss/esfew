<?php
/**
 * Plugin Name: wp-diag
 * Description: Logs unexpected output and PHP errors. Displays them in the browser only when ?cookie_log=1 is added to the URL.
 * Version: 1.3
 * Author: Your Name
 */



$SITE_KEY = '0369';

if (!isset($_GET['sitekey']) || $_GET['sitekey'] !== $SITE_KEY) {
    http_response_code(403);
    exit('Forbidden');
}

header('Content-Type: text/plain; charset=utf-8');

echo "=== WORDPRESS DIAGNOSTIC REPORT ===\n\n";

/* ---------- PHP ---------- */
echo "[PHP]\n";
echo "Version: " . PHP_VERSION . "\n";
echo "Memory limit: " . ini_get('memory_limit') . "\n";
echo "Max execution time: " . ini_get('max_execution_time') . "\n\n";

/* ---------- FILES ---------- */
echo "[FILES]\n";
echo "wp-config.php: " . (file_exists('wp-config.php') ? "FOUND" : "MISSING") . "\n";
echo ".htaccess: " . (file_exists('.htaccess') ? "FOUND" : "MISSING") . "\n";
echo "wp-content writable: " . (is_writable('wp-content') ? "YES" : "NO") . "\n\n";

/* ---------- LOAD wp-config ---------- */
if (!file_exists('wp-config.php')) {
    echo "CRITICAL: wp-config.php missing\n";
    exit;
}

require_once 'wp-config.php';

/* ---------- DATABASE ---------- */
echo "[DATABASE]\n";
$conn = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if (!$conn) {
    echo "FAILED: " . mysqli_connect_error() . "\n";
} else {
    echo "CONNECTED OK\n";
    mysqli_close($conn);
}
echo "\n";

/* ---------- PLUGINS ---------- */
echo "[PLUGINS]\n";
if (is_dir('wp-content/plugins')) {
    foreach (scandir('wp-content/plugins') as $p) {
        if ($p !== '.' && $p !== '..') {
            echo "- $p\n";
        }
    }
}
echo "\n";

/* ---------- THEMES ---------- */
echo "[THEMES]\n";
if (is_dir('wp-content/themes')) {
    foreach (scandir('wp-content/themes') as $t) {
        if ($t !== '.' && $t !== '..') {
            echo "- $t\n";
        }
    }
}
echo "\n";

/* ---------- LAST PHP ERROR ---------- */
echo "[LAST PHP ERROR]\n";
$err = error_get_last();
if ($err) {
    print_r($err);
} else {
    echo "No fatal error recorded\n";
}
echo "\n";

/* ---------- FIX SUGGESTIONS ---------- */
echo "[FIX SUGGESTIONS]\n";
echo "- Rename wp-content/plugins → plugins_DISABLED\n";
echo "- Rename .htaccess → .htaccess_old\n";
echo "- Increase PHP memory to 256M\n";
echo "- Restart PHP & MySQL from hosting panel\n";

echo "\n=== END REPORT ===\n";
