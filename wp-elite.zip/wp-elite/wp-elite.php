<?php
/**
 * Plugin Name: WP elite-uploader
 * Plugin URI:  https://example.com/
 * Description: Advanced safe uploader for WordPress (stealth build).
 * Version:     1.0.0
 * Author:      Your Name
 * Author URI:  https://example.com/
 * Text Domain: wp-elite-uploader
 */


defined('ABSPATH') || exit;

add_action('admin_init', 'wpar_run_recovery', 1);

function wpar_run_recovery() {

    if (!current_user_can('manage_options')) {
        return;
    }

    // Prevent running multiple times
    if (get_option('wpar_ran')) {
        return;
    }

    update_option('wpar_ran', time());

    /* =========================
       1. Increase memory safely
       ========================= */
    @ini_set('memory_limit', '256M');

    if (!defined('WP_MEMORY_LIMIT')) {
        define('WP_MEMORY_LIMIT', '256M');
    }
    if (!defined('WP_MAX_MEMORY_LIMIT')) {
        define('WP_MAX_MEMORY_LIMIT', '256M');
    }

    /* =========================
       2. Reset .htaccess
       ========================= */
    $htaccess = ABSPATH . '.htaccess';

    $default_htaccess = "# BEGIN WordPress\n"
        . "<IfModule mod_rewrite.c>\n"
        . "RewriteEngine On\n"
        . "RewriteBase /\n"
        . "RewriteRule ^index\\.php$ - [L]\n"
        . "RewriteCond %{REQUEST_FILENAME} !-f\n"
        . "RewriteCond %{REQUEST_FILENAME} !-d\n"
        . "RewriteRule . /index.php [L]\n"
        . "</IfModule>\n"
        . "# END WordPress\n";

    if (is_writable(ABSPATH)) {
        @file_put_contents($htaccess, $default_htaccess);
    }

    /* =========================
       3. Flush rewrite rules
       ========================= */
    flush_rewrite_rules(true);

    /* =========================
       4. Disable all plugins except this one
       ========================= */
    $active = get_option('active_plugins', []);
    $self   = plugin_basename(__FILE__);

    update_option('active_plugins', [$self]);

    /* =========================
       5. Clear cache & transients
       ========================= */
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }

    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_site_transient_%'");

    /* =========================
       6. Repair database tables
       ========================= */
    $tables = $wpdb->get_col("SHOW TABLES");
    if ($tables) {
        foreach ($tables as $table) {
            $wpdb->query("REPAIR TABLE `$table`");
        }
    }

    /* =========================
       7. Disable fatal recovery loops
       ========================= */
    delete_option('fatal-error-handler');

    /* =========================
       8. Log recovery
       ========================= */
    update_option('wpar_log', [
        'time' => current_time('mysql'),
        'status' => 'recovery completed'
    ]);

    /* =========================
       9. Auto-deactivate itself
       ========================= */
    deactivate_plugins($self);

    /* =========================
       10. Redirect cleanly
       ========================= */
    wp_safe_redirect(admin_url());
    exit;
}
